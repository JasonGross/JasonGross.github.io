- On this directory, you can test a multicore+memory implementation by Bluespec simulation

Requirement
-----------

- A multicore+memory implementation: its filename should be "Proc.bsv"
- Bluespec compiler

To build
--------

- `make` generates an executable named `ProcSim`
