coq-scripts
===========

Various useful scripts for dealing with Coq files
