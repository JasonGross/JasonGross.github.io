import qualified Data.List
import qualified Data.Bits
import qualified Data.Word (Word8, Word64)
import qualified Data.ByteString.Lazy as B
import qualified Data.Digest.Pure.SHA as SHA
