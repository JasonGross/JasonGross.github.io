Usage:

python fill_template.py 41417_32.json

(overwrites GF41417_32.v)
